#################################################################
#Built By Aryan Biswas (http://aryanbiswasgroup.co.nf/)		#
#Copyright 2014 Indian High School (http://ihsdxb.com/)		#
#Roundsquare AGM 2015 Staff Console Ver 1.1 (Linux,Firefox)	#
#################################################################

-The Package

This package is for restricted use only, do not redistribute
this in any means as it contains confidential data and access
to restricted workspaces.

-How to Run it

Make sure you have Mozzila Firefox Installed.

Create a directory .RSAGM2015 in the home folder

Create a directoty StaffConsoleFirefox inside the .RSAGM2015 folder
and extract the archive contents there

Right Click on the start.sh file and set permissons to "Allow executing
file as program".

Copy and paste the RSAGM2015StaffConsoleFirefox.desktop file at your
desktop and right click and set permissons to "Allow executing file
as program"

Clicking on the desktop shortcut will run the web app.

If you have any query, contact -

Aryan Biswas
aryandevbiswas@gmail.com
+971 56 771 0591
