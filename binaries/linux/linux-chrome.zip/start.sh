#################################################################
#Built By Aryan Biswas (http://aryanbiswasgroup.co.nf/)		#
#Copyright 2014 Indian High School (http://ihsdxb.com/)		#
#Roundsquare AGM 2015 Staff Console Ver 1.2 (Linux,Chrome)	#
#################################################################
google-chrome --app=http://ihsroundsquare.net/staff/webapp
