#########################################################
#Built By Aryan Biswas (http://aryanbiswasgroup.co.nf/)	#
#Copyright 2014 Indian High School (http://ihsdxb.com/)	#
#Roundsquare AGM 2015 Staff Console Ver 1.1 (Mac,Chrome	#
#########################################################

-The Package

This package is for restricted use only, do not redistribute
this in any means as it contains confidential data and access
to restricted workspaces.

-How to Run it

This package cannot be installed.

Make sure you have Google Chrome Installed.

Create a directory RSAGM2015 in the home folder and extract
the archive contents there.

Right Click on the start.sh file and set permissons to "Allow executing
file as program".

Open a terminal and paste the following command -

~/RSAGM2015/start.sh

The Web App shall start running, save that command as you will
need it every time you start the program.

If you have any query, contact -

Aryan Biswas
aryandevbiswas@gmail.com
+971 56 771 0591
